# Watch the Screencast
[![Authentication from Scratch in Rails 5](https://images.rubyplus.com/rubyplus-screencast.png)](https://rubyplus.com/episodes/311-Authentication-from-Scratch-in-Rails-5)
