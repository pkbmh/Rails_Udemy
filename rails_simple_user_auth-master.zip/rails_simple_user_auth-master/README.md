rails_simple_user_auth
======================

Repository accompanying User/Password Authenticaion from Scratch article (http://rubysource.com/?p=3611)